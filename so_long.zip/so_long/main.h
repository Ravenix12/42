/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: smariapp <smariapp@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/22 14:54:26 by smariapp          #+#    #+#             */
/*   Updated: 2025/08/22 20:30:54 by smariapp         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MAIN_H
# define MAIN_H

# include <fcntl.h>
# include <stddef.h>
# include <unistd.h>
# include <stdlib.h>
# include <stdio.h>
# include "get_next_line/get_next_line.h"
# include "Libft/libft.h"
 
typedef struct player
{
	int	exit;
	int player;
	int collectibles;
	int collected;
}	p;

//parsing
int		check_walls(char *line, size_t length);
void	parse_map(int fd);
int		check_epc(p *info, char *line, int final);
void	error_exit(char *error, int fd, char *line, p *info);

//utilities
size_t	nl(char *str);

#endif