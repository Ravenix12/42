/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: smariapp <smariapp@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/22 14:54:26 by smariapp          #+#    #+#             */
/*   Updated: 2025/08/30 22:11:50 by smariapp         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MAIN_H
# define MAIN_H

# include <fcntl.h>
# include <stddef.h>
# include <unistd.h>
# include <stdlib.h>
# include <stdio.h>
# include "get_next_line/get_next_line.h"
# include "Libft/libft.h"
# include "minilibx-linux/mlx.h"
# include </usr/include/X11/X.h>
# include </usr/include/X11/keysymdef.h>

# define WIDTH 960
# define HEIGHT 768

# define ESC 0xff1b
# define UP 0xff52
# define DOWN 0xff54
# define LEFT 0xff51
# define RIGHT 0xff53

typedef struct s_player
{
	int	exit;
	int	player;
	int	collectibles;
	int	collected;
	int	lines;
	int	length;
}	t_p;

typedef struct s_data
{
	void	*mlx;
	void	*win;
}	t_data;

typedef struct s_display
{
	void	**player;
	void	*collectible;
	void	**wall;
	void	*emp;
	void	**exit;
}	t_dis;

typedef struct params
{
	t_data	*data;
	t_p		*info;
	t_dis	*display;
	char	**map;
}	t_par;

//parsing
int		check_walls(char *line, int length);
t_p		*check_invalid(int fd);
int		check_epc(t_p *info, char *line, int final);
void	error_exit(char *error, int fd, char *line, t_p *info);

//utilities
int		nl(char *str);
void	free_arr(char **arr);

//map_config
char	**save_map(int fd, t_p *info);
void	free_player(char **arr, t_p *info);
void	malloc_exit(char **arr, t_p *info);
void	print_map(char **arr); //remove
int		*find_coordinates(char **map, char c, t_p *info);
char	**duplicate_map(char **map, t_p *info);
//solvable;
char	**solvable_entry(int fd, t_p *info);
void	check_solvable(char **dup, char **map, t_p *info);

//floodfill
void	fill_vertical(char **map, int *coor, t_p *info);
void	fill_horizontal(char **map, int *coor, t_p *info);
void	assign(char **map, int *coor, char c, t_p *info);

//lib
void	lib_entry(char **map, t_p *info);
t_par	*set_param(char **map, t_p *info, t_data *data, t_dis *dis);

//init_pics
void	set_display(t_dis	*image, char **map, t_p *info, t_data *data);
int		set_image(void **location, char *path, t_data *data, int flag);
void	free_display(t_data *data, t_dis *images);
void	malloc_fail(char **map, t_p *info, t_data *data, t_dis *images);

//input_handling
int		handle_inputs(t_par *params);
int		ft_keypress(int keycode, t_par *params);
int		ft_close(t_par *params);

//display
void	display_cf(int i, t_par *params);
void	display_ncf(int i, int j, t_par *params);
void	display_screen(t_par *params);

#endif