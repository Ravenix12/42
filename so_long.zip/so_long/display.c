/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   display.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: smariapp <smariapp@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/30 19:09:53 by smariapp          #+#    #+#             */
/*   Updated: 2025/08/30 22:10:26 by smariapp         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main.h"

void	display_cf(int i, t_par *params)
{
	int	j;
	int	length;
	
	j = 0;
	length = params->info->length;
	while (i == 0 && j < length)
	{
		mlx_put_image_to_window(params->data->mlx, params->data->win,
			params->display->wall[0], j * 64, i * 64);
		j++;
	}
	if (j == length)
		return;
	j = 1;
	while (i == params->info->lines - 1 && j < length - 1)
	{
		mlx_put_image_to_window(params->data->mlx, params->data->win,
			params->display->wall[1], j * 64, i * 64);
		j++;
	}
	mlx_put_image_to_window(params->data->mlx, params->data->win,
			params->display->wall[2], 0, i * 64);
	mlx_put_image_to_window(params->data->mlx, params->data->win,
			params->display->wall[2], j * 64, i * 64);
	
}

void	display_ncf(int i, int j, t_par *params)
{
	int		length;

	length = params->info->length;
	if (params->map[i][j] == '0')
		mlx_put_image_to_window(params->data->mlx, params->data->win,
			params->display->emp, j * 64, i * 64);
	if (params->map[i][j] == '1')
		mlx_put_image_to_window(params->data->mlx, params->data->win,
			params->display->wall[2], j * 64, i * 64);
	if (params->map[i][j] == 'C')
		mlx_put_image_to_window(params->data->mlx, params->data->win,
			params->display->collectible, j * 64, i * 64);
	if (params->map[i][j] == 'E')
		mlx_put_image_to_window(params->data->mlx, params->data->win,
			params->display->exit[0], j * 64, i * 64);
	if (params->map[i][j] == 'O')
		mlx_put_image_to_window(params->data->mlx, params->data->win,
			params->display->exit[1], j * 64, i * 64);
	if (params->map[i][j] == 'L')
		mlx_put_image_to_window(params->data->mlx, params->data->win,
			params->display->player[0], j * 64, i * 64);
	if (params->map[i][j] == 'P')
		mlx_put_image_to_window(params->data->mlx, params->data->win,
			params->display->player[1], j * 64, i * 64);
}

void	display_screen(t_par *params)
{
	int		lines;
	int		length;
	int		i;
	int		j;
	char	**map;

	i = 0;
	lines = params->info->lines;
	length = params->info->length;
	map = params->map;
	while (i < lines)
	{
		j = 0;
		if (i == 0 || i == lines - 1)
			display_cf(i, params);
		while (i > 0 && i < lines - 1 && j < length)
		{	
			display_ncf(i, j, params);
			j++;
		}		
		i++;
	}
}
