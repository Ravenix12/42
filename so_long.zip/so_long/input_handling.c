/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   input_handling.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: smariapp <smariapp@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/29 16:07:21 by smariapp          #+#    #+#             */
/*   Updated: 2025/08/30 17:02:13 by smariapp         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main.h"

int	ft_close(t_par *params)
{
	free_display(params->data, params->display);
	free_player(params->map, params->info);
	free(params);
	exit(0);
	return (0);
}

int	ft_keypress(int keycode, t_par *params)
{
	if (keycode == ESC)
		ft_close(params);
	return (0);
}

int	handle_inputs(t_par *params)
{
	mlx_hook(params->data->win, DestroyNotify, StructureNotifyMask, &ft_close, params);
	mlx_hook(params->data->win, KeyPress, KeyPressMask, &ft_keypress, params);
	return (0);
}
