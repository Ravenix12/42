/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: smariapp <smariapp@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/22 14:52:26 by smariapp          #+#    #+#             */
/*   Updated: 2025/08/22 20:38:56 by smariapp         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main.h"

int	gimme_fd(char *file)
{
	int	fd;

	fd = open(file, O_RDONLY);
	if (fd < 0)
	{
		perror(file);
		exit(1);
	}
	return (fd);
}

int	main(int argc, char **argv)
{
	int	fd;

	if (argc != 2)
	{
		write(2, "Error\nIvalid Arguments\n", 23);
		exit(1);
	}
	fd = gimme_fd(argv[1]);
	parse_map(fd);
	fd = gimme_fd(argv[1]);
	printf("here");
}
